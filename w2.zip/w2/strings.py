import os
os.system('cls')

print('hi!')

a = ' my'
print(len(a))

#  string 
name=str(input('tell me your name:'))
print(name)

